package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;

public class Koneksi {

    private static Connection koneksi;

    public static Connection getKoneksi(){

        try{

            if(koneksi==null){

                Class.forName("com.mysql.jdbc.Driver");

                koneksi=DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/coffeeshop",
                        "root",
                        ""
                );

                System.out.println("Koneksi Berhasil");

            }

        }catch(Exception e){

            System.out.println("Koneksi Gagal : "+e);

        }

        return koneksi;

    }

}